Original AI-created demonstration, not a client case.
22-second silent H.264 portrait video. All artwork is from the original mushroom-lift.html/SVG.
Quick re-render from the extracted ZIP folder: python render_demo.py. Requires Pillow, FFmpeg, FFprobe and the Windows Segoe UI/Georgia fonts. Included PNG layers are enough for this step. Output goes in ./outputs.
Optional SVG-layer re-render: node render-original-video-art.cjs. Install Playwright in the extracted folder (npm install playwright) before running this optional script. Requires Chromium/Edge. The HTML and portable SVG contain original room styling.
No downloaded music or client footage. Motion is camera reframing plus lift movement, not character rigging.
