from pathlib import Path
import subprocess, json, math, zipfile
from PIL import Image, ImageDraw, ImageFont

BASE=Path(__file__).resolve().parent
ROOT=BASE.parents[1]
OUT=ROOT/'outputs'
if not (OUT/'mushroom-lift.html').exists():
 OUT=BASE/'outputs'
OUT.mkdir(exist_ok=True)
FPS=24
DURATION=22
W,H=1080,1920
PAPER='#faf5e9'
INK='#382f24'
RUST='#b74f35'
MOSS='#526949'
REG='C:/Windows/Fonts/segoeui.ttf'
BOLD='C:/Windows/Fonts/segoeuib.ttf'
SERIF='C:/Windows/Fonts/georgia.ttf'
def font(n,bold=False,serif=False):
 return ImageFont.truetype(SERIF if serif else BOLD if bold else REG,n)
def label(im,xy,s,n,c=INK,b=False,serif=False):
 ImageDraw.Draw(im).text(xy,s,font=font(n,b,serif),fill=c)
bg=Image.open(BASE/'mushroom-background.png').convert('RGBA')
cabin=Image.open(BASE/'cabin.png').convert('RGBA')
camera=[(0,300,325,600),(2.5,300,325,580),(4.5,339,487,285),(7.5,339,487,265),(9,339,382,285),(12,339,382,270),(13.5,339,266,285),(16.5,339,266,268),(19,300,325,575),(22,300,325,600)]
lift=[(0,230),(7.2,230),(8.9,115),(11.6,115),(13.5,0),(18,0),(20.4,230),(22,230)]
def interpolate(points,t):
 for a,b in zip(points,points[1:]):
  if a[0]<=t<=b[0]:
   u=(t-a[0])/(b[0]-a[0]);u=u*u*(3-2*u)
   return tuple(x+(y-x)*u for x,y in zip(a[1:],b[1:]))
 return points[-1][1:]
def frame(t):
 art=Image.new('RGBA',(1600,1800),PAPER)
 art.alpha_composite(bg,(200,200))
 offset=interpolate(lift,t)[0]
 art.alpha_composite(cabin,(200,200+round(offset*2)))
 cx,cy,cw=interpolate(camera,t);ch=cw*1.25
 crop=(round(200+(cx-cw/2)*2),round(200+(cy-ch/2)*2),round(200+(cx+cw/2)*2),round(200+(cy+ch/2)*2))
 # Cameras stay in the padded original-art canvas; no invented assets.
 assert min(crop)>=0 and crop[2]<=1600 and crop[3]<=1800
 art=art.crop(crop).resize((960,1200),Image.Resampling.BICUBIC)
 im=Image.new('RGB',(W,H),PAPER)
 d=ImageDraw.Draw(im)
 d.rectangle((64,102,74,132),fill=RUST)
 label(im,(92,99),'ORIGINAL AI-CREATED DEMO',26,MOSS,True)
 label(im,(60,171),'One little lift.',83,INK,False,True)
 label(im,(64,281),'A small story from original SVG artwork.',29,'#756b58')
 im.paste(art,(60,360),art)
 d.line((64,1597,1016,1597),fill='#d5c8b1',width=2)
 if t<3.5:
  head='Welcome to Morel House.';body='Three rooms. One acorn courier.'
 elif t<8:
  head='01  Snail Mail Studio';body="Express delivery. At a snail's pace."
 elif t<12.6:
  head='02  Moonjam Kitchen';body='One spoonful of night.'
 elif t<18.2:
  head='03  Cloud Sock Loft';body='A laundry day forecast: mostly socks.'
 else:
  head='An illustration, brought into motion.';body='Original artwork. Camera moves. A simple story.'
 label(im,(64,1645),head,39,INK,True)
 label(im,(64,1710),body,28,'#756b58')
 label(im,(64,1826),'ILLUSTRATION + MOTION STUDY  /  SILENT DEMO',21,MOSS,True)
 d.line((64,1890,1016,1890),fill='#d5c8b1',width=3)
 d.line((64,1890,64+round(952*t/DURATION),1890),fill=RUST,width=5)
 return im

output=OUT/'freelancer-video-demo.mp4'
proc=subprocess.Popen(['ffmpeg','-hide_banner','-loglevel','error','-y','-f','rawvideo','-pix_fmt','rgb24','-s',f'{W}x{H}','-r',str(FPS),'-i','-','-an','-c:v','libx264','-preset','veryfast','-crf','22','-pix_fmt','yuv420p','-movflags','+faststart',str(output)],stdin=subprocess.PIPE,stderr=subprocess.PIPE)
preview_times=[1,5.5,10.5,15.5,20.5]
for i in range(FPS*DURATION):
 im=frame(i/FPS)
 proc.stdin.write(im.tobytes())
 for t in preview_times:
  if i==round(t*FPS): im.save(BASE/f'frame-{t}.png')
proc.stdin.close()
error=proc.stderr.read().decode(errors='replace');code=proc.wait()
assert code==0,error

# 4:3 service cover, displaying original stills from the generated video.
cover=Image.new('RGB',(1200,900),'#f0ede7')
label(cover,(43,40),'SMALL, FOCUSED VIDEO DELIVERABLES',17,MOSS,True)
label(cover,(42,88),'Vertical video',61,INK,True)
label(cover,(42,158),'from your assets',61,INK,True)
label(cover,(46,247),'AI-driven edit  /  Original illustration demo',23,RUST,True)
for x,t in [(45,1),(326,10.5),(607,15.5)]:
 img=frame(t).resize((258,459),Image.Resampling.LANCZOS)
 ImageDraw.Draw(cover).rounded_rectangle((x-3,311,x+261,776),radius=12,fill='#d1c6b2')
 cover.paste(img,(x,314))
label(cover,(900,338),'22 sec',38,INK,True)
label(cover,(900,400),'1080 × 1920',22,MOSS,True)
label(cover,(900,447),'Camera moves',19,'#756b58')
label(cover,(900,480),'Lift motion',19,'#756b58')
label(cover,(900,513),'Clear captions',19,'#756b58')
label(cover,(900,631),'Original SVG art',19,MOSS,True)
label(cover,(900,666),'Silent demo',19,'#756b58')
label(cover,(44,835),'A clear sequence, made from material you already own.',26,INK,True)
cover.save(OUT/'freelancer-video-service-cover.png',optimize=True)

probe=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_streams','-show_format','-of','json',str(output)]))
v=next(s for s in probe['streams'] if s['codec_type']=='video')
decode=subprocess.run(['ffmpeg','-v','error','-i',str(output),'-f','null','-'],capture_output=True,text=True)
assert decode.returncode==0 and not decode.stderr
assert v['width']==W and v['height']==H and abs(float(probe['format']['duration'])-DURATION)<.05
assert not any(s['codec_type']=='audio' for s in probe['streams'])
qa={'file':output.name,'duration_seconds':float(probe['format']['duration']),'width':W,'height':H,'fps':FPS,'frames':int(v['nb_frames']),'codec':v['codec_name'],'audio':'none; intentionally silent','full_decode':'passed; no errors','bytes':output.stat().st_size,'source':'Original mushroom HTML/SVG from this workspace. No client images, music downloads, external contacts or real customer case claims.','motion':'Continuous smooth camera reframing and lift cabin movement. Captions set locally.','visual_review':'pending','cover':{'width':1200,'height':900,'bytes':(OUT/'freelancer-video-service-cover.png').stat().st_size}}
(OUT/'freelancer-video-demo-qa.json').write_text(json.dumps(qa,indent=2),encoding='utf-8')
(BASE/'README.txt').write_text('Original AI-created demonstration, not a client case.\n22-second silent H.264 portrait video. All artwork is from the original mushroom-lift.html/SVG.\nQuick re-render from the extracted ZIP folder: python render_demo.py. Requires Pillow, FFmpeg, FFprobe and the Windows Segoe UI/Georgia fonts. Included PNG layers are enough for this step. Output goes in ./outputs.\nOptional SVG-layer re-render: node render-original-video-art.cjs. Its Playwright require path points at the bundled runtime on the author machine; replace that require path with your installed Playwright. Requires Chromium/Edge. The HTML and portable SVG contain original room styling.\nNo downloaded music or client footage. Motion is camera reframing plus lift movement, not character rigging.\n',encoding='utf-8')
with zipfile.ZipFile(OUT/'freelancer-video-demo-source.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in [BASE/'original-mushroom.svg',BASE/'mushroom-background.png',BASE/'cabin.png',BASE/'render_demo.py',BASE/'README.txt',(BASE.parent/'render-original-video-art.cjs') if (BASE.parent/'render-original-video-art.cjs').exists() else BASE/'render-original-video-art.cjs',(ROOT/'outputs/mushroom-lift.html') if (ROOT/'outputs/mushroom-lift.html').exists() else BASE/'mushroom-lift.html']:
  z.write(p,p.name)
print(json.dumps(qa,indent=2))
