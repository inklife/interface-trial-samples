#!/usr/bin/env python3
"""News Scout: a small, standard-library RSS demonstration. Python 3.10+."""
from __future__ import annotations

import argparse
import csv
import datetime as dt
import email.utils
import hashlib
import http.client
import io
import ipaddress
import json
import re
import secrets
import socket
import ssl
import threading
import urllib.parse
import xml.etree.ElementTree as ET
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

ROOT = Path(__file__).resolve().parent
MAX_FEED_BYTES = 1024 * 1024
MAX_ITEMS_PER_FEED = 200
UTC = dt.timezone.utc


class FeedError(ValueError):
    """An expected configuration, transport, or feed validation failure."""


def plain_text(value: str, limit: int = 300) -> str:
    """Store only headline metadata, never article bodies or HTML markup."""
    return re.sub(r"\s+", " ", re.sub(r"<[^>]*>", "", value or "")).strip()[:limit]


def article_url(value: str) -> str:
    """Article links are displayed, never fetched. Reject active URL schemes."""
    if any(ord(c) < 32 for c in value):
        raise FeedError("Article link contains control characters")
    parsed = urllib.parse.urlsplit(value.strip())
    if parsed.scheme not in {"https", "http"} or not parsed.hostname or parsed.username or parsed.password:
        raise FeedError("Article link must be an ordinary HTTP(S) URL")
    try:
        address = ipaddress.ip_address(parsed.hostname)
    except ValueError:
        if parsed.hostname.lower() in {"localhost", "localhost.localdomain"} or parsed.hostname.lower().endswith(".localhost"):
            raise FeedError("Local article link rejected")
    else:
        if not address.is_global:
            raise FeedError("Private or local article link rejected")
    tracking = {"fbclid", "gclid", "mc_cid", "mc_eid"}
    query = [(k, v) for k, v in urllib.parse.parse_qsl(parsed.query, keep_blank_values=True)
             if not k.lower().startswith("utm_") and k.lower() not in tracking]
    host = parsed.hostname.lower()
    if ":" in host:
        host = f"[{host}]"
    try:
        port = parsed.port
    except ValueError as exc:
        raise FeedError("Invalid article port") from exc
    if port and not (parsed.scheme == "https" and port == 443 or parsed.scheme == "http" and port == 80):
        host += f":{port}"
    return urllib.parse.urlunsplit((parsed.scheme.lower(), host, parsed.path or "/", urllib.parse.urlencode(sorted(query)), ""))


def published_date(value: str) -> str:
    try:
        date = email.utils.parsedate_to_datetime(value)
        if date.tzinfo is None:
            date = date.replace(tzinfo=UTC)
        return date.astimezone(UTC).isoformat().replace("+00:00", "Z")
    except (TypeError, ValueError, OverflowError):
        return ""


def parse_feed(data: bytes, source: dict) -> list[dict]:
    if len(data) > MAX_FEED_BYTES:
        raise FeedError("Feed exceeds the 1 MiB limit")
    try:
        data.decode("utf-8")
    except UnicodeDecodeError as exc:
        raise FeedError("Only UTF-8 RSS XML is accepted") from exc
    if b"\x00" in data:
        raise FeedError("NUL bytes and non-UTF-8 XML are not accepted")
    upper = data.upper()
    if b"<!DOCTYPE" in upper or b"<!ENTITY" in upper:
        raise FeedError("DTD and entity declarations are not accepted")
    try:
        root = ET.fromstring(data)
    except ET.ParseError as exc:
        raise FeedError("Malformed RSS XML") from exc
    if root.tag != "rss" or root.find("channel") is None:
        raise FeedError("Expected an RSS 2.0 channel")
    items = root.findall("./channel/item")
    if len(items) > MAX_ITEMS_PER_FEED:
        raise FeedError("Feed exceeds the 200-item limit")
    records = []
    for item in items:
        title = plain_text(item.findtext("title", ""))
        raw_link = item.findtext("link", "").strip()
        if not title or not raw_link:
            continue
        try:
            link = article_url(raw_link)
        except FeedError:
            continue
        records.append({
            "id": hashlib.sha256(link.encode("utf-8")).hexdigest()[:20],
            "title": title,
            "published_at": published_date(item.findtext("pubDate", "")),
            "source_id": source["id"], "source": source["name"], "url": link,
            "sample": source["kind"] == "fixture",
        })
    return records


def validated_remote_target(url: str) -> tuple[str, str, str]:
    """Resolve once, require all answers public, and pin the selected address."""
    if len(url) > 2048 or any(ord(c) < 32 for c in url):
        raise FeedError("Invalid feed URL")
    parsed = urllib.parse.urlsplit(url)
    try:
        valid_port = parsed.port in {None, 443}
    except ValueError:
        valid_port = False
    if parsed.scheme != "https" or not parsed.hostname or parsed.username or parsed.password or parsed.fragment or not valid_port:
        raise FeedError("Configured remote feeds must use HTTPS on port 443, without credentials or fragment")
    hostname = parsed.hostname.encode("idna").decode("ascii").lower()
    if hostname in {"localhost", "localhost.localdomain"} or hostname.endswith((".localhost", ".local", ".internal")):
        raise FeedError("Local feed host rejected")
    try:
        answers = socket.getaddrinfo(hostname, 443, type=socket.SOCK_STREAM)
    except OSError as exc:
        raise FeedError("Feed hostname could not be resolved") from exc
    addresses = list(dict.fromkeys(answer[4][0] for answer in answers))
    if not addresses or any(not ipaddress.ip_address(address).is_global for address in addresses):
        raise FeedError("Private, loopback, link-local, reserved, or mixed DNS answers rejected")
    path = urllib.parse.urlunsplit(("", "", parsed.path or "/", parsed.query, ""))
    return hostname, addresses[0], path


class PinnedHTTPSConnection(http.client.HTTPSConnection):
    """TLS verifies the allowlisted hostname; connect uses its validated IP."""
    def __init__(self, hostname: str, address: str):
        super().__init__(hostname, timeout=8, context=ssl.create_default_context())
        self.address = address

    def connect(self):
        raw = socket.create_connection((self.address, 443), self.timeout)
        try:
            self.sock = self._context.wrap_socket(raw, server_hostname=self.host)
        except Exception:
            raw.close()
            raise


def load_feed(source: dict) -> bytes:
    if source["kind"] == "fixture":
        target = (ROOT / source["path"]).resolve()
        if ROOT not in target.parents or target.suffix != ".xml":
            raise FeedError("Fixture path must be an XML file inside this project")
        try:
            with target.open("rb") as stream:
                data = stream.read(MAX_FEED_BYTES + 1)
        except OSError as exc:
            raise FeedError("Fixture file could not be read") from exc
        return data
    if source["kind"] != "https":
        raise FeedError("Unsupported source kind")
    hostname, address, path = validated_remote_target(source["url"])
    connection = PinnedHTTPSConnection(hostname, address)
    try:
        connection.request("GET", path, headers={"User-Agent": "NewsScout-Demo/1.0", "Accept": "application/rss+xml, application/xml", "Accept-Encoding": "identity"})
        response = connection.getresponse()
        # No redirects: a new host or destination needs explicit local configuration.
        if response.status != 200:
            raise FeedError(f"Feed returned HTTP {response.status}; redirects are not followed")
        if response.getheader("Content-Encoding", "identity") != "identity":
            raise FeedError("Compressed feed response is not supported")
        data = response.read(MAX_FEED_BYTES + 1)
        if len(data) > MAX_FEED_BYTES:
            raise FeedError("Feed exceeds the 1 MiB limit")
        return data
    except (OSError, http.client.HTTPException) as exc:
        raise FeedError("Feed request failed or timed out") from exc
    finally:
        connection.close()


def load_sources(path: Path) -> dict[str, dict]:
    sources = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(sources, list) or len(sources) > 10:
        raise FeedError("Configure a list of at most 10 allowlisted sources")
    result = {}
    for source in sources:
        if not isinstance(source, dict) or not re.fullmatch(r"[a-z][a-z0-9-]{0,39}", source.get("id", "")):
            raise FeedError("Invalid source ID")
        if source["id"] in result or source.get("kind") not in {"fixture", "https"} or not source.get("name"):
            raise FeedError("Invalid or repeated source")
        result[source["id"]] = dict(source)
    return result


def csv_text(records: list[dict]) -> str:
    output = io.StringIO(newline="")
    writer = csv.writer(output)
    writer.writerow(["Title", "Published UTC", "Source", "Original URL", "Synthetic sample"])
    for item in records:
        def safe(value):
            text = str(value)
            return "'" + text if text.lstrip().startswith(("=", "+", "-", "@")) else text
        writer.writerow([safe(item["title"]), item["published_at"], safe(item["source"]), item["url"], "yes" if item["sample"] else "no"])
    return output.getvalue()


class NewsStore:
    def __init__(self, sources: dict[str, dict]):
        self.sources = sources
        self.records = {}
        self.last_run = None
        self.lock = threading.RLock()
        self.collect_lock = threading.Lock()

    def collect(self, ids: list[str]) -> dict:
        if not ids or len(ids) != len(set(ids)) or any(source not in self.sources for source in ids):
            raise FeedError("Choose unique IDs from the configured source allowlist")
        inserted, duplicates, errors = 0, 0, []
        if not self.collect_lock.acquire(blocking=False):
            raise FeedError("Another collection is already running")
        try:
            for source_id in ids:
                source = self.sources[source_id]
                try:
                    incoming = parse_feed(load_feed(source), source)
                    with self.lock:
                        for record in incoming:
                            if record["id"] in self.records:
                                duplicates += 1
                            elif len(self.records) >= 2000:
                                raise FeedError("Metadata store is full; restart the demonstration")
                            else:
                                self.records[record["id"]] = record
                                inserted += 1
                except FeedError as exc:
                    errors.append({"source_id": source_id, "message": str(exc)})
            with self.lock:
                self.last_run = dt.datetime.now(UTC).isoformat().replace("+00:00", "Z")
            return {"inserted": inserted, "duplicates": duplicates, "errors": errors, "last_run": self.last_run}
        finally:
            self.collect_lock.release()

    def query(self, keyword: str = "", source: str = "") -> list[dict]:
        if source and source not in self.sources:
            raise FeedError("Unknown source filter")
        if len(keyword) > 160:
            raise FeedError("Keyword exceeds 160 characters")
        words = [re.compile(r"(?<!\w)" + re.escape(word) + r"(?!\w)") for word in keyword.casefold().split()]
        with self.lock:
            rows = [dict(record) for record in self.records.values()
                    if (not source or record["source_id"] == source) and all(word.search(record["title"].casefold()) for word in words)]
        return sorted(rows, key=lambda row: (row["published_at"], row["title"]), reverse=True)


class ScoutServer(ThreadingHTTPServer):
    daemon_threads = True

    def __init__(self, address, sources):
        super().__init__(address, ScoutHandler)
        self.store = NewsStore(sources)
        self.token = secrets.token_urlsafe(32)
        # Seed only fixtures. This performs no network request, even if the local
        # config also includes authorized remote sources.
        fixtures = [key for key, item in sources.items() if item["kind"] == "fixture"]
        if fixtures:
            self.store.collect(fixtures)


class ScoutHandler(BaseHTTPRequestHandler):
    server_version = "NewsScout/1.0"

    def log_message(self, format, *args):
        # Do not print query contents or URLs; local terminal stays concise.
        return

    def send_payload(self, status: int, payload: bytes, content_type: str, extra=None):
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(payload)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Referrer-Policy", "no-referrer")
        self.send_header("Content-Security-Policy", "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'")
        for key, value in (extra or {}).items():
            self.send_header(key, value)
        self.end_headers()
        self.wfile.write(payload)

    def json_response(self, status: int, payload):
        self.send_payload(status, json.dumps(payload, ensure_ascii=False).encode("utf-8"), "application/json; charset=utf-8")

    def valid_host(self) -> bool:
        port = self.server.server_address[1]
        return self.headers.get("Host") in {f"127.0.0.1:{port}", f"localhost:{port}"}

    def do_GET(self):
        if not self.valid_host():
            return self.json_response(400, {"error": "Unsupported Host header"})
        parsed = urllib.parse.urlsplit(self.path)
        params = urllib.parse.parse_qs(parsed.query)
        try:
            if parsed.path == "/api/state":
                rows = self.server.store.query(params.get("q", [""])[0], params.get("source", [""])[0])
                sources = [{"id": item["id"], "name": item["name"], "kind": item["kind"]} for item in self.server.store.sources.values()]
                return self.json_response(200, {"items": rows, "sources": sources, "total": len(self.server.store.query()), "last_run": self.server.store.last_run, "token": self.server.token})
            if parsed.path == "/api/export.csv":
                rows = self.server.store.query(params.get("q", [""])[0], params.get("source", [""])[0])
                return self.send_payload(200, ("\ufeff" + csv_text(rows)).encode("utf-8"), "text/csv; charset=utf-8", {"Content-Disposition": 'attachment; filename="news-scout.csv"'})
            allowed = {"/": ("index.html", "text/html; charset=utf-8"), "/app.js": ("app.js", "text/javascript; charset=utf-8"), "/style.css": ("style.css", "text/css; charset=utf-8")}
            if parsed.path not in allowed:
                return self.json_response(404, {"error": "Not found"})
            filename, mime = allowed[parsed.path]
            return self.send_payload(200, (ROOT / "static" / filename).read_bytes(), mime)
        except FeedError as exc:
            return self.json_response(400, {"error": str(exc)})

    def do_POST(self):
        if not self.valid_host():
            return self.json_response(400, {"error": "Unsupported Host header"})
        if self.path != "/api/collect":
            return self.json_response(404, {"error": "Not found"})
        host = self.headers.get("Host")
        origin = self.headers.get("Origin")
        if origin and origin not in {f"http://{host}", f"https://{host}"}:
            return self.json_response(403, {"error": "Cross-origin collection rejected"})
        if not secrets.compare_digest(self.headers.get("X-Scout-Token", "").encode("utf-8"), self.server.token.encode("utf-8")):
            return self.json_response(403, {"error": "Collection token required"})
        try:
            length = int(self.headers.get("Content-Length", "0"))
            if not 0 < length <= 8192 or not self.headers.get("Content-Type", "").startswith("application/json"):
                raise FeedError("Send a JSON body no larger than 8192 bytes")
            body = json.loads(self.rfile.read(length))
            if not isinstance(body, dict) or set(body) != {"source_ids"} or not isinstance(body["source_ids"], list) or any(not isinstance(x, str) for x in body["source_ids"]):
                raise FeedError("Only a source_ids list is accepted; arbitrary URLs are not accepted")
            result = self.server.store.collect(body["source_ids"])
            self.json_response(200, result)
        except (FeedError, ValueError, json.JSONDecodeError) as exc:
            self.json_response(400, {"error": str(exc)})


def main():
    parser = argparse.ArgumentParser(description="Run the local News Scout demonstration")
    parser.add_argument("--port", type=int, default=8187)
    parser.add_argument("--config", type=Path, default=ROOT / "sources.json")
    args = parser.parse_args()
    sources = load_sources(args.config)
    server = ScoutServer(("127.0.0.1", args.port), sources)
    print(f"News Scout ready at http://127.0.0.1:{server.server_address[1]} — AI-created synthetic demonstration", flush=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
