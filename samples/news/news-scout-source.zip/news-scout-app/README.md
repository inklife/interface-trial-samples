# News Scout — runnable RSS demonstration

An original AI-created demonstration prepared for the public request **Web-Based News Keyword/Topic news Scraper**, Freelancer project **40742608**:
https://www.freelancer.com/projects/web-development/web-based-news-keyword-topic

This is a new sample, not a previous client project. It has **not** been installed on the buyer's server. All 12 default RSS entries are original fictional headlines; after cross-feed deduplication there are 11 articles. Their `.example` links are reserved demonstration URLs, not real news reports.

## Run locally

Requires Python **3.10 or later**. No package installation, API keys, accounts, or third-party assets are required.

```sh
cd news-scout-app
python app.py --port 8187
```

Open **http://127.0.0.1:8187**. The server seeds its metadata store by actually parsing the three fixture XML files, without making network requests. Click **Collect feeds** to parse the configured sources again. Repeated collection skips duplicates. Stop with Ctrl+C.

Features implemented:

- Responsive English browser UI and manual RSS collection.
- Case-insensitive whole-word title keyword search: space-separated terms use AND matching. Searching `AI` does not also match `repair` or `daily`.
- Source filter, headline, source name, normalized UTC publication date, original article link.
- Deduplication by normalized article URL; common tracking parameters and fragments are removed. If an article appears in multiple feeds, its first collected source is retained.
- Filter-aware CSV download, UTF-8 BOM, and spreadsheet formula neutralization.
- Per-source errors preserve previously collected items.

The in-memory metadata store resets when the Python process restarts. No full article text is downloaded or cached. A feed without a valid publication date shows “Date not supplied”. This version supports UTF-8 RSS 2.0; Atom, general HTML scraping and paywalled sources are outside this sample.

## Add an authorized RSS source

Only sources listed in the local `sources.json` file can be collected. The web API accepts configured source IDs, **never a URL supplied by a visitor**. Obtain the feed owner's permission and check the applicable usage rules before enabling a remote source. Prefer a publisher-provided RSS feed or documented API; don't bypass accounts, CAPTCHAs, paywalls or access controls.

Add a source object locally, using a unique short ID:

```json
{
  "id": "authorized-feed",
  "name": "Authorized Publisher",
  "kind": "https",
  "url": "https://YOUR-AUTHORIZED-FEED-HOST/rss.xml"
}
```

The placeholder above is deliberately not a working source. Replace it with an approved feed address and restart the app. Remote feeds are **not** fetched during startup; manual collection must select the configured source ID. Up to 10 sources are accepted. Default fixtures remain entirely offline.

Remote transport requires HTTPS port 443, verifies TLS for the configured hostname, rejects credentials and fragments, validates **every** DNS answer as public, and connects to a pinned validated IP to avoid a second DNS resolution. It rejects loopback, private, link-local and reserved destinations and mixed public/private DNS answers. Redirects and compressed responses are not followed. Each request has an 8-second socket timeout; each RSS response is limited to 1 MiB and 200 items. DTD/entity declarations, NUL bytes and malformed XML are rejected. Article links are only displayed and are never fetched.

This bounded demonstration is not a security audit of a production deployment. Use server-level egress controls as another boundary when deploying an internet-connected collector.

## Deployment outline

For an agreed server deployment, confirm the OS, Python availability, domain/TLS, intended audience, authorized source URLs, exact fields, collection interval and acceptance criteria first.

1. Copy the source folder to the approved server and use a supported Python runtime.
2. Configure approved sources in `sources.json` and run the HTTP tests below.
3. Run `python app.py --port 8187` under the server's service manager as an unprivileged account. It listens on **127.0.0.1** only.
4. Put an HTTPS reverse proxy in front. Forward the upstream Host header as **127.0.0.1:8187**. The backend deliberately rejects arbitrary Host headers. If proxying a browser origin, adapt the explicit origin validation to the one approved public origin before enabling collection; the default accepts local-origin collection only.
5. Add authentication/access restrictions at the proxy, operational logging, source retention policy, egress restrictions, and persistent storage as the agreed production scope requires.
6. Verify each authorized source and browser workflow on the actual deployment environment. This package does not assert that such deployment occurred.

The client's brief requests **automatic** scraping. This demonstration implements **manual** collection, plus fixture-only startup seeding. No background scheduler is included. A collection interval, rate limits, source formats, persistence, and server environment must be agreed before committing to the automatic version. It is not a promise to scrape unspecified websites within the public budget.

## Verify

```sh
python -m unittest -v test_app.py
```

The tests start a real local HTTP server on a free port, parse the RSS fixtures, verify 12 input items become 11 unique articles, exercise keyword/source filtering, re-collection, CSV contents, invalid feed handling, source-ID restrictions, CSRF/origin controls, static file boundaries and public-DNS requirements. They do not access public news sites or represent tests on the buyer's server.

## Optional static preview

```sh
python build_static.py
python -m http.server 8188 --bind 127.0.0.1 --directory static-demo
```

Open **http://127.0.0.1:8188**. Publish only the contents of `static-demo/` to a normal static hosting path if desired. This preview offers the same synthetic headline filters and client-side CSV export. **Reload samples** is explicitly a simulation: it does not collect remote feeds. Actual XML parsing and guarded remote collection require the Python application.

## Files

- `app.py`: collector, feed validation, metadata store and HTTP routes.
- `sources.json`: explicit local source allowlist.
- `fixtures/*.xml`: three original synthetic RSS feeds.
- `static/`: original HTML, CSS and JavaScript UI; no external fonts or libraries.
- `test_app.py`: functional and boundary tests.
- `build_static.py`, `static-demo/`: optional standalone static demonstration.
- `LICENSE`: permission to reuse the original demonstration code and sample assets.

No user credentials, wallet addresses, employer contacts or customer source materials are bundled.
