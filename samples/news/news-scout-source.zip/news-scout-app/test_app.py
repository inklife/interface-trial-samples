"""Functional HTTP and feed boundary checks; no public network requests."""
import csv
import io
import json
import socket
import threading
import unittest
import urllib.error
import urllib.request
from unittest.mock import patch

import app


class NewsScoutTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.server = app.ScoutServer(("127.0.0.1", 0), app.load_sources(app.ROOT / "sources.json"))
        cls.thread = threading.Thread(target=cls.server.serve_forever, daemon=True)
        cls.thread.start()
        cls.base = "http://127.0.0.1:" + str(cls.server.server_address[1])

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown()
        cls.server.server_close()
        cls.thread.join(timeout=2)

    def request(self, path, body=None, token=True, extra=None):
        headers = dict(extra or {})
        if body is not None:
            headers["Content-Type"] = "application/json"
            if token:
                headers["X-Scout-Token"] = self.server.token
        request = urllib.request.Request(self.base + path, data=None if body is None else json.dumps(body).encode(), headers=headers)
        try:
            response = urllib.request.urlopen(request, timeout=4)
        except urllib.error.HTTPError as exc:
            response = exc
        with response:
            return response.status, response.headers, response.read()

    def get_json(self, path):
        status, _, data = self.request(path)
        self.assertEqual(status, 200)
        return json.loads(data)

    def test_01_actual_fixture_parse_and_unique_count(self):
        parsed = []
        for source in self.server.store.sources.values():
            parsed += app.parse_feed(app.load_feed(source), source)
        self.assertEqual(len(parsed), 12)
        self.assertEqual(len({record["url"] for record in parsed}), 11)
        data = self.get_json("/api/state")
        self.assertEqual(data["total"], 11)
        self.assertEqual(len(data["items"]), 11)
        self.assertTrue(all(item["sample"] for item in data["items"]))
        self.assertEqual(data["items"][0]["title"], "Open research toolkit turns sensor readings into clearer signals")
        self.assertEqual(data["items"][0]["published_at"], "2026-10-01T07:00:00Z")
        self.assertTrue(all("utm_" not in item["url"] for item in data["items"]))
        self.assertTrue(all("description" not in item for item in data["items"]))

    def test_02_repeat_collection_does_not_duplicate(self):
        status, _, raw = self.request("/api/collect", {"source_ids": ["fieldnotes", "cleancurrent", "civicdesk"]})
        self.assertEqual(status, 200)
        data = json.loads(raw)
        self.assertEqual(data["inserted"], 0)
        self.assertEqual(data["duplicates"], 12)
        self.assertEqual(data["errors"], [])
        self.assertEqual(self.get_json("/api/state")["total"], 11)

    def test_03_keyword_and_source_filters(self):
        energy = self.get_json("/api/state?q=ENERGY")
        self.assertEqual(len(energy["items"]), 2)
        self.assertTrue(all("energy" in item["title"].lower() for item in energy["items"]))
        self.assertEqual(len(self.get_json("/api/state?q=AI")["items"]), 2)
        self.assertEqual(len(self.get_json("/api/state?source=cleancurrent")["items"]), 3)
        selected = self.get_json("/api/state?q=energy&source=cleancurrent")["items"]
        self.assertEqual(len(selected), 1)
        self.assertEqual(selected[0]["title"], "Campus energy dashboard makes daily demand visible")
        self.assertEqual(self.get_json("/api/state?q=no-match-here")["items"], [])
        self.assertEqual(self.request("/api/state?source=not-allowed")[0], 400)

    def test_04_csv_matches_filtered_http_results(self):
        status, headers, raw = self.request("/api/export.csv?q=energy")
        self.assertEqual(status, 200)
        self.assertTrue(headers["Content-Type"].startswith("text/csv"))
        rows = list(csv.reader(io.StringIO(raw.decode("utf-8-sig"))))
        self.assertEqual(rows[0], ["Title", "Published UTC", "Source", "Original URL", "Synthetic sample"])
        self.assertEqual(len(rows), 3)
        self.assertEqual({row[0] for row in rows[1:]}, {item["title"] for item in self.get_json("/api/state?q=energy")["items"]})
        self.assertTrue(all(row[4] == "yes" for row in rows[1:]))

    def test_05_csv_formula_cells_are_neutralized(self):
        text = app.csv_text([{"title": "=2+2", "source": "@A1", "published_at": "", "url": "https://press.example/story", "sample": True}])
        row = list(csv.reader(io.StringIO(text)))[1]
        self.assertEqual(row[0], "'=2+2")
        self.assertEqual(row[2], "'@A1")

    def test_06_arbitrary_urls_and_unknown_source_ids_rejected(self):
        for body in [{"url": "http://127.0.0.1:9000"}, {"source_ids": ["http://127.0.0.1"]}, {"source_ids": []}, {"source_ids": ["fieldnotes", "fieldnotes"]}, {"source_ids": [42]}, {"source_ids": ["fieldnotes"], "url": "https://example.com"}]:
            with self.subTest(body=body):
                self.assertEqual(self.request("/api/collect", body)[0], 400)

    def test_07_cross_origin_and_token_controls(self):
        body = {"source_ids": ["fieldnotes"]}
        self.assertEqual(self.request("/api/collect", body, token=False)[0], 403)
        self.assertEqual(self.request("/api/collect", body, extra={"Origin": "https://outside.example"})[0], 403)
        self.assertEqual(self.request("/api/state", extra={"Host": "outside.example"})[0], 400)

    def test_08_malformed_xml_and_entities_fail_cleanly(self):
        source = self.server.store.sources["fieldnotes"]
        for value in [b"<broken", b"<html>not RSS</html>", b'<!DOCTYPE rss [<!ENTITY x "boom">]><rss><channel/></rss>', b"<rss>\x00</rss>", b"x" * (app.MAX_FEED_BYTES + 1)]:
            with self.subTest(value=value[:80]):
                with self.assertRaises(app.FeedError):
                    app.parse_feed(value, source)

    def test_09_one_failed_source_preserves_existing_results(self):
        self.server.store.sources["missing-fixture"] = {"id": "missing-fixture", "name": "Missing synthetic feed", "kind": "fixture", "path": "fixtures/does-not-exist.xml"}
        try:
            status, _, raw = self.request("/api/collect", {"source_ids": ["missing-fixture"]})
            self.assertEqual(status, 200)
            result = json.loads(raw)
            self.assertEqual(result["inserted"], 0)
            self.assertEqual(len(result["errors"]), 1)
            self.assertEqual(result["errors"][0]["source_id"], "missing-fixture")
            self.assertEqual(self.get_json("/api/state")["total"], 11)
        finally:
            del self.server.store.sources["missing-fixture"]

    def test_10_feed_urls_require_public_https(self):
        for url in ["http://feeds.example/rss", "https://localhost/rss", "https://host.local/rss", "https://user:secret@feeds.example/rss", "https://feeds.example:8443/rss", "https://feeds.example/rss#fragment"]:
            with self.subTest(url=url), self.assertRaises(app.FeedError):
                app.validated_remote_target(url)
        for address in ["127.0.0.1", "::1", "10.0.0.1", "169.254.169.254", "192.168.1.1", "0.0.0.0"]:
            answer = [(socket.AF_INET, socket.SOCK_STREAM, 6, "", (address, 443))]
            with patch("app.socket.getaddrinfo", return_value=answer), self.subTest(address=address), self.assertRaises(app.FeedError):
                app.validated_remote_target("https://feeds.example/rss")
        answers = [(socket.AF_INET, socket.SOCK_STREAM, 6, "", ("93.184.216.34", 443)), (socket.AF_INET, socket.SOCK_STREAM, 6, "", ("10.0.0.1", 443))]
        with patch("app.socket.getaddrinfo", return_value=answers), self.assertRaises(app.FeedError):
            app.validated_remote_target("https://feeds.example/rss")
        with patch("app.socket.getaddrinfo", return_value=answers[:1]):
            self.assertEqual(app.validated_remote_target("https://feeds.example/rss?a=1"), ("feeds.example", "93.184.216.34", "/rss?a=1"))

    def test_11_article_links_cannot_be_active_or_local(self):
        for link in ["javascript:alert(1)", "data:text/html,bad", "http://localhost/story", "https://127.0.0.1/story", "https://192.168.1.2/story", "https://[::1]/story"]:
            with self.subTest(link=link), self.assertRaises(app.FeedError):
                app.article_url(link)
        self.assertEqual(app.article_url("https://press.example/item?utm_source=test&topic=ai#part"), "https://press.example/item?topic=ai")

    def test_12_static_files_and_path_boundary(self):
        for path, mime in [("/", "text/html"), ("/app.js", "text/javascript"), ("/style.css", "text/css")]:
            status, headers, raw = self.request(path)
            self.assertEqual(status, 200)
            self.assertTrue(headers["Content-Type"].startswith(mime))
            self.assertGreater(len(raw), 100)
            self.assertEqual(headers["X-Content-Type-Options"], "nosniff")
        self.assertEqual(self.request("/../sources.json")[0], 404)
        self.assertEqual(self.request("/sources.json")[0], 404)


if __name__ == "__main__":
    unittest.main(verbosity=2)
