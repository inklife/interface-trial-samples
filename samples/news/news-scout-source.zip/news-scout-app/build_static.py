"""Create a static synthetic preview for GitHub Pages, without any network."""
import json
import shutil
from pathlib import Path
import app

def main():
    target = app.ROOT / "static-demo"
    target.mkdir(exist_ok=True)
    sources = app.load_sources(app.ROOT / "sources.json")
    store = app.NewsStore(sources)
    store.collect([key for key, item in sources.items() if item["kind"] == "fixture"])
    payload = {"items": store.query(), "sources": [{"id": item["id"], "name": item["name"], "kind": "fixture"} for item in sources.values() if item["kind"] == "fixture"], "total": len(store.query()), "last_run": store.last_run, "token": None}
    (target / "demo-data.json").write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    html = (app.ROOT / "static/index.html").read_text(encoding="utf-8")
    html = html.replace('<body>', '<body data-mode="static">').replace('href="/style.css"', 'href="style.css"').replace('src="/app.js"', 'src="app.js"').replace('href="/"', 'href="index.html"')
    html = html.replace("Collect feeds</button>", "Reload samples</button>")
    html = html.replace("No customer websites or paid content have been collected.", "No customer websites or paid content have been collected. This static preview simulates collection; use the Python app for actual RSS parsing.")
    (target / "index.html").write_text(html, encoding="utf-8")
    for filename in ["app.js", "style.css"]:
        shutil.copyfile(app.ROOT / "static" / filename, target / filename)
    print(f"Static synthetic preview prepared: {target}")

if __name__ == "__main__":
    main()
